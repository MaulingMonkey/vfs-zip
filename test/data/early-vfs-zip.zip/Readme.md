# `vfs-zip`

Virtual filesystem abstractions for ZIP files.

Currently this is mainly meant for use with the [`vfs`](https://lib.rs/crates/vfs)
crate.  However, this has several points of tensions:

1.  vfs::[FileSystem](https://docs.rs/vfs/0.4.0/vfs/filesystem/trait.FileSystem.html) requires `Sync` whereas `zip` is single threaded.
2.  vfs::[FileSystem](https://docs.rs/vfs/0.4.0/vfs/filesystem/trait.FileSystem.html) requires `'static`

## Features

* `default`
* [`vfs`](https://lib.rs/crates/vfs) (0.4 interop)

## License

Licensed under either of

* Apache License, Version 2.0 ([LICENSE-APACHE](LICENSE-APACHE) or http://www.apache.org/licenses/LICENSE-2.0)
* MIT license ([LICENSE-MIT](LICENSE-MIT) or http://opensource.org/licenses/MIT)

at your option.

## Contribution

Unless you explicitly state otherwise, any contribution intentionally submitted
for inclusion in the work by you, as defined in the Apache-2.0 license, shall be
dual licensed as above, without any additional terms or conditions.
