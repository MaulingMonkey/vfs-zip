#![cfg_attr(external_doc, feature(external_doc))]
#![cfg_attr(external_doc, doc(include = "../Readme.md"))]

pub use zip;
#[cfg(feature = "vfs")] pub use vfs;

mod read;   pub use read::*;
mod write;  pub use write::*;
