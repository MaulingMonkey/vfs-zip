use std::collections::*;
use std::fmt::{self, Debug, Formatter};
use std::io::{Read, Seek};
use std::sync::Mutex;

pub use zip::result::{ZipError as Error, ZipResult as Result};

pub struct ZipArchive<IO: Read + Seek + Send + 'static> {
    archive:    Mutex<zip::read::ZipArchive<IO>>,
    files:      BTreeMap<String, usize>,            // abs path -> zip archive index
    dirs:       BTreeMap<String, BTreeSet<String>>, // abs path -> [relative file/dir names]
}

impl<IO: Read + Seek + Send + 'static> Debug for ZipArchive<IO> {
    fn fmt(&self, fmt: &mut Formatter) -> fmt::Result {
        write!(fmt, "ZipArchive")
    }
}

impl<IO: Read + Seek + Send> ZipArchive<IO> {
    pub fn new(io: IO) -> Result<Self> {
        let mut za = Self {
            archive:    Mutex::new(zip::read::ZipArchive::new(io)?),
            files:      Default::default(),
            dirs:       Default::default(),
        };

        let mut archive = za.archive.lock().unwrap();
        for (i, mut file) in archive.file_names().enumerate() {
            debug_assert!(!file.contains("\\")); // ?
            if za.files.insert(file.into(), i).is_some() { continue; } // already inserted?

            while let Some(slash) = file.rfind(is_path_separator) {
                let dir_name = &file[..slash];
                let file_name = &file[slash+1..];

                let dir = za.dirs.entry(dir_name.into()).or_default();
                dir.insert(file_name.into());

                file = dir_name;
            }
        }

        for (abs, index) in &za.files {
            debug_assert!(archive.by_index(*index).unwrap().name() == abs);
        }

        std::mem::drop(archive); // unlock

        Ok(za)
    }
}

#[cfg(feature = "vfs")] mod _vfs_support {
    use super::*;
    use vfs::*;
    use std::io::Write;

    impl<IO: Read + Seek + Send + 'static> FileSystem for ZipArchive<IO> {
        fn read_dir     (&self, path: &str)             -> VfsResult<Box<dyn Iterator<Item = String>>>  { unimplemented!() }
        fn create_dir   (&self, _path: &str)            -> VfsResult<()>                                { Err(VfsError::NotSupported) }
        fn open_file    (&self, path: &str)             -> VfsResult<Box<dyn SeekAndRead>>              { unimplemented!() }
        fn create_file  (&self, _path: &str)            -> VfsResult<Box<dyn Write>>                    { Err(VfsError::NotSupported) }
        fn append_file  (&self, _path: &str)            -> VfsResult<Box<dyn Write>>                    { Err(VfsError::NotSupported) }
        fn metadata     (&self, path: &str)             -> VfsResult<VfsMetadata>                       { unimplemented!() }
        fn exists       (&self, path: &str)             -> bool                                         { unimplemented!() }
        fn remove_file  (&self, _path: &str)            -> VfsResult<()>                                { Err(VfsError::NotSupported) }
        fn remove_dir   (&self, _path: &str)            -> VfsResult<()>                                { Err(VfsError::NotSupported) }
        fn copy_file    (&self, _src: &str, _dst: &str )-> VfsResult<()>                                { Err(VfsError::NotSupported) }
        fn move_file    (&self, _src: &str, _dst: &str )-> VfsResult<()>                                { Err(VfsError::NotSupported) }
        fn move_dir     (&self, _src: &str, _dst: &str )-> VfsResult<()>                                { Err(VfsError::NotSupported) }
    }

    #[cfg(all(test, windows))] mod _tests {
        use super::*;
        use std::convert::*;
        use std::fs::File;
        use std::path::*;

        fn create_zip_archive() -> ZipArchive<File> {
            let path = PathBuf::from(std::env::var_os("USERPROFILE").unwrap()).join(r".cargo\registry\cache\github.com-1ecc6299db9ec823\zip-0.5.6.crate");
            ZipArchive::new(File::open(path).unwrap()).unwrap()
        }

        #[test] fn test() {
            //let cza = create_zip_archive();
        }
    }
}

fn is_path_separator(ch: char) -> bool {
    ch == '/' || ch == '\\'
}
