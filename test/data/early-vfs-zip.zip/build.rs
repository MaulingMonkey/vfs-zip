use std::process::Command;



fn main() {
    let o = Command::new("rustc").arg("--version").output().expect("rustc --version failed to run");
    let stdout = String::from_utf8(o.stdout).expect("rustc --version stdout contained non-utf8");
    let mut fragments = stdout.split_ascii_whitespace();

    let _rustc  = fragments.next().unwrap_or("");                           // "rustc"
    let _ver    = fragments.next().unwrap_or("");                           // "1.47.0-nightly"
    let _hash   = fragments.next().unwrap_or("").trim_start_matches('(');   // "(bf4342114"
    let _date   = fragments.next().unwrap_or("").trim_end_matches(')');     // "2020-08-25)"

    if _ver.ends_with("-nightly") {
        println!("cargo:rustc-cfg=external_doc");
    }
}
